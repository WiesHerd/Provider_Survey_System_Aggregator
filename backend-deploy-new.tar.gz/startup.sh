#!/bin/bash
cd /home/site/wwwroot
npm install --production
node server.js
